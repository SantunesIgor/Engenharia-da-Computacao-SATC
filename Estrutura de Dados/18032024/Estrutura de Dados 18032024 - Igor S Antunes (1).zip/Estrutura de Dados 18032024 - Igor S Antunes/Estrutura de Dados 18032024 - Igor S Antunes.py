import os

list = []

menu = '''Qual ação você deseja fazer na lista?

1 - Inserir um elemento
2 - Pesquisar um elemento
3 - Excluir um elemento
4 - Imprimir a lista
0 - Encerrar o programa
'''

menuum = '''1 - Inserir um elemento

a) Inserir na última posição
b) Inserir na posição desejada
c) Voltar ao menu principal
'''

menudois = '''2 - Pesquisar um elemento

a) Pequisar pelo valor
b) Pesquisar pelo índice
c) Voltar ao menu principal
'''

menutres = '''3 - Excluir um elemento

a) Excluir pelo valor
b) Excluir pelo índice
c) Voltar ao menu principal
'''

print('''
##########################################
########## ArrayList de Strings ##########
##########################################

Aluno: Ígor da Silva Antunes - 1º Fase
      ''')

while True:
    print(menu)

    try:
        act = int(input('Digite a opção desejada: '))
    except:
        os.system('cls')
        print('Valor inválido!')
        continue

    if act == 1:
        os.system('cls')
        print(menuum)
        act = input('Digite a opção desejada: ').lower()

        if act == 'a':
            val = input('Digite o elemento a ser inserido: ')
            list.append(val)
            os.system('cls')
            print("Você adicionou '%s' à ultima posição da sua lista\n" %(val))

        elif act == 'b':
            pos = int(input('Digite a posição a ser inserida: '))
            if pos > len(list):
                os.system('cls')
                print('Por favor, digite uma posição válida')
                continue
            val = input('Digite o elemento a ser inserido: ')
            list.insert(pos, val)
            os.system('cls')
            print("Você adicionou '%s' à posição '%i' da sua lista\n" %(val, pos))
        
        elif act == 'c': 
            os.system('cls')
            continue

        else:
            os.system('cls')
            print('Valor inválido!')

    elif act == 2:
        os.system('cls')
        print(menudois)
        act = input('Digite a opção desejada: ').lower()

        if act == 'a':
            val = input('Digite o valor a ser pesquisado: ')
            if val in list:
                os.system('cls')
                print("O valor %s está na lista no índice %i" %(val, list.index(val)))
            else:
                os.system('cls')
                print("O valor não está na lista")

        elif act == 'b':
            try:
                ind = int(input('Digite o índice desejado: '))
            except:
                os.system('cls')
                print('Valor inválido!')
                continue

            if ind > len(list):
                os.system('cls')
                print('Índice inválido')
            else:
                os.system('cls')
                print('O valor no índice é de', list[ind])

        elif act == 'c': 
            os.system('cls')
            continue

        else:
            os.system('cls')
            print('Valor inválido!')

    elif act == 3:
        os.system('cls')
        print(menutres)
        act = input('Digite a opção desejada: ').lower()

        if act == 'a':
            val = input("Digite o valor que deseja excluir: ")
            if val in list:
                list.remove(val)
                os.system('cls')
                print("Você excluiu o valor '%s' da lista" %(val))
            else:
                os.system('cls')
                print('O valor que você escreveu não está na lista')

        elif act == 'b':
            val = int(input("Digite o índice do valor que deseja excluir: "))
            if len(list) < val:
                os.system('cls')
                print('Não há valor nesse índice')
            else:
                list.pop(val)
                os.system('cls')
                print("Você excluiu o valor do índice %i" %(val))

        elif act == 'c': 
            os.system('cls')
            continue

        else:
            os.system('cls')
            print('Valor inválido!')

    elif act == 4:
        os.system('cls')
        for i in list:
            print("Índice %i - %s" %(list.index(i), i))
        if list == []:
            print('Não há elementos na lista')
    
    elif act == 0:
        break

    else:
        os.system('cls')
        print('Valor inválido!')