import os
from pilhaestatica import PilhaEstatica

menu = ('''1 - Criar a pilha
2 - Adicionar elementos na pilha
3 - Remover elementos da pilha
4 - Imprimir
5 - Verificar pilha cheia
6 - Verificar pilha vazia
7 - Quantidade de elemetos
''')

menu2 = ('''1 - Recriar pilha
2 - Adicionar elementos na pilha
3 - Remover elementos da pilha
4 - Imprimir
5 - Verificar pilha cheia
6 - Verificar pilha vazia
7 - Quantidade de elemetos
''')

var = 0

while True:
    if var == 0:
        print(menu)
    else:
        print(menu2)
    opc = int(input('Digite a opção desejada: '))
    os.system('cls')
    match opc:
        case 1:
            cap = int(input('Digite a capacidade desejada: '))
            pilha = PilhaEstatica(cap)
            var = 1
        case 2:
            ele = input('Digite o elemento: ')
            pilha.empilhar(ele)
        case 3: pilha.desempilhar()
        case 4:
            while pilha.vazia() == False:
                print(pilha.topo_da_pilha())
                pilha.desempilhar()
        case 5: 
            if pilha.cheia(): print('A pilha está cheia.')
            else: print('A pilha não está cheia')
        case 6:
            if pilha.vazia(): print('A pilha está vazia.')
            else: print('A pilha não está vazia')
        case 7: print(pilha.tamanho())