class PilhaEstatica:
    def __init__(self, capacidade):
        self.capacidade = capacidade
        self.topo = -1
        self.pilha = [None] * capacidade

    def vazia(self):
        return self.topo == -1
    
    def cheia(self):
        return self.topo == self.capacidade - 1
    
    def empilhar(self, elemento):
        if self.cheia():
            print('A pilha está cheia. Não é possível adicionar mais elementos.')
            return
        self.topo += 1
        self.pilha[self.topo] = elemento

    def desempilhar(self):
        if self.vazia():
            print('A pilha está vazia. Não é possível remover elementos.')
            return None
        elemento = self.pilha[self.topo]
        self.topo-= 1
        return elemento
    
    def topo_da_pilha(self):
        if self.vazia():
            print('A pilha está vazia')
            return None
        return self.pilha[self.topo]
    
    def tamanho(self):
        return self.topo + 1
    
pilha = PilhaEstatica(5)
print(pilha)